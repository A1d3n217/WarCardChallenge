//
//  ContentView.swift
//  WarCardChallenge
//
//  Created by Wood, Aiden - Student on 9/27/24.
//

import SwiftUI

struct ContentView: View {
    
    @State var playerCard = "card2"
    @State var cpuCard = "card2"
    @State var playerScore = 0
    @State var cpuScore = 0
    @State var playerName = "Player"
    
    var body: some View {
       
        VStack {
            Image("logo")
            Spacer()
            HStack {
                Spacer()
                Image(playerCard)
                Spacer()
                Image(cpuCard)
                Spacer()
            }
           Spacer()
            
            Button(action: {
                deal()
            }, label: {
                Image("button")
            })
            
            Spacer()
            HStack {
               Spacer()
                VStack {
                    Text(playerName)
                        .foregroundStyle(.white)
                        .font(.headline)
                        .padding(.bottom, 10.0)
                    Text(String(playerScore))
                        .foregroundStyle(.white)
                        .font(.largeTitle)
                }
                Spacer()
                VStack {
                    Text("CPU")
                        .foregroundStyle(.white)
                        .font(.headline)
                        .padding(.bottom, 10.0)
                    Text(String(cpuScore))
                        .foregroundStyle(.white)
                        .font(.largeTitle)
                }
                Spacer()
            }
            Spacer()
            VStack {
                TextField("Name", text: $playerName)
                    .textFieldStyle(.roundedBorder)
                    .padding()
            }
        }
        .background(
        Image("background-wood-cartoon")
        )
    }
    
    func deal(){
       var playerCardValue = Int.random(in: 2...14)
        playerCard = "card" + String(playerCardValue)
        var cpuCardValue = Int.random(in: 2...14)
        cpuCard = "card" + String(cpuCardValue)
        if playerCardValue > cpuCardValue {
            playerScore += 1
        }
        else if cpuCardValue > playerCardValue {
            cpuScore += 1
        }
        
    }
}

#Preview {
    ContentView()
}
