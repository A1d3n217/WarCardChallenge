//
//  WarCardChallengeApp.swift
//  WarCardChallenge
//
//  Created by Wood, Aiden - Student on 9/27/24.
//

import SwiftUI

@main
struct WarCardChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
